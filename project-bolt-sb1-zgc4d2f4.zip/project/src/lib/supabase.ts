import { createClient } from '@supabase/supabase-js';

// These will be populated when the user connects to Supabase
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type HungerRecord = {
  id: string;
  created_at: string;
  user_id: string;
  start_time: string;
  end_time: string | null;
  duration_seconds: number | null;
};